import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

public class Zadanie1C {
    public static void main(String[] args) {
        Set<String> mySet;
        Set<String> SetOfAnimals = new ConcurrentSkipListSet<String>();
        SetOfAnimals.add("Cat");
        SetOfAnimals.add("Dog");
        SetOfAnimals.add("Bird");
        SetOfAnimals.add("Fish");
        mySet = Collections.synchronizedSet(SetOfAnimals);
        HandleThread(mySet, true);
        HandleThread(mySet, false);
    }

    public static void HandleThread(Set<String> reader, boolean isThatFirstSet) {
        Runnable check = () -> {
            synchronized (reader) {
                System.out.println("Started: " + Thread.currentThread().getName());
                Iterator<String> iterator = reader.iterator();
                if (isThatFirstSet) {
                    while (iterator.hasNext()) {
                        reader.remove("Fish");
                        System.out.println("-> " + iterator.next());
                    }
                    System.out.println("Ended: " + Thread.currentThread().getName());
                } else {
                    while (iterator.hasNext()) {
                        reader.add("Panda");
                        System.out.println("-> " + iterator.next());
                    }
                    System.out.println("Ended: " + Thread.currentThread().getName());
                }
            }
        };
        Thread Thread;
        if (isThatFirstSet) {
            Thread = new Thread(check, "First Thread");
        } else {
            Thread = new Thread(check, "Second Thread");
        }
        Thread.start();
    }
}