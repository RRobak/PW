import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public class Zadanie1D {

    public static void main(String[] args) {
        Set<String> mySet;
        Set<String> SetOfAnimals = new CopyOnWriteArraySet<String>();
        SetOfAnimals.add("Cat");
        SetOfAnimals.add("Dog");
        SetOfAnimals.add("Bird");
        SetOfAnimals.add("Fish");
        mySet = Collections.synchronizedSet(SetOfAnimals);
        Iterator<String> iterator = mySet.iterator();
        while (iterator.hasNext()) {
            mySet.remove("Fish");
            System.out.println("-> " + iterator.next());
        }
        HandleThread(mySet, true);
        HandleThread(mySet, false);
        while (iterator.hasNext()) {
            System.out.println("-> " + iterator.next());
        }
    }

    public static void HandleThread(Set<String> Reader, boolean isThatFirstSet) {
        Runnable Check = () -> {
            synchronized (Reader) {
                System.out.println("\nStarted: " + Thread.currentThread().getName());
                Iterator<String> iterator = Reader.iterator();
                if (isThatFirstSet) {
                    while (iterator.hasNext()) {
                        Reader.remove("Fish");
                        System.out.println("-> " + iterator.next());
                    }
                    System.out.println("Ended: " + Thread.currentThread().getName());
                } else {
                    Reader.add("Panda");
                    while (iterator.hasNext()) {

                        System.out.println("-> " + iterator.next());
                    }
                    System.out.println("Ended: " + Thread.currentThread().getName());
                }

            }
        };
        Thread Thread;
        if (isThatFirstSet) {
            Thread = new Thread(Check, "First Thread");
        } else {
            Thread = new Thread(Check, "Second Thread");
        }
        Thread.start();
    }
}