import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Zadanie1A {
    public static void main(String[] args) {
        Set<String> mySet;
        HashSet<String> SetOfAnimals = new HashSet<>();
        SetOfAnimals.add("Cat");
        SetOfAnimals.add("Dog");
        SetOfAnimals.add("Bird");
        SetOfAnimals.add("Fish");
        mySet = Collections.synchronizedSet(SetOfAnimals);
        HandleThread(mySet, true);
        HandleThread(mySet, false);
    }

    public static void HandleThread(Set<String> listener, boolean isThatFirstSet) {
        Runnable check = () -> {
            synchronized (listener) { 
                System.out.println("Started: " + Thread.currentThread().getName());
                Iterator<String> iterator = listener.iterator();
                while (iterator.hasNext()) {
                    String currValue = iterator.next();
                    System.out.println(Thread.currentThread().getName() + " -> " + currValue);
                }
                System.out.println("Ended: " + Thread.currentThread().getName());
            }
        };
        Thread thread;
        if (isThatFirstSet) {
            thread = new Thread(check, "First Thread");
        } else {
            thread = new Thread(check, "Second Thread");
        }
        thread.start();
    }
}