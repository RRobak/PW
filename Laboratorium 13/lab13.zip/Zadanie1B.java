import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Zadanie1B {
    public static void main(String[] args) {
        Set<String> mySet = Collections.synchronizedSet(new HashSet<String>());
        Thread Thread1 = new Thread(new Example((mySet), true));
        Thread Thread2 = new Thread(new Example((mySet), false));
        Thread1.start();
        Thread2.start();

        try {
            Thread1.join();
            Thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Size of set after asynchronic operations:" + mySet.size() + "\nZawartość setu:\n");

        for (String iterator : mySet) {
            System.out.println(iterator);
        }
    }
}

class Example implements Runnable {
    private Set<String> OutSet;
    private boolean first;

    public Example(Set<String> val, boolean isFirst) {
        this.first = isFirst;
        this.OutSet = val;
    }

    @Override
    public void run() {
        System.out.println("Run()" + Thread.currentThread().getName());
        int i;
        if (first) {
            for (i = 0; i < 5; i++) {
                OutSet.add(String.valueOf(i * 20));
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } else {
            for (i = 0; i < 5; i++) {
                OutSet.add(String.valueOf(i * 45));
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}